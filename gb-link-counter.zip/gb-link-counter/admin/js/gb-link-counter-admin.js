let body = document.querySelector('body');

const config = { 
    attributes: false, 
    childList: true, 
    subtree: true,
};

const callback = (mutationList, observer) => {         
    let editorRootDiv = body.querySelector('.is-root-container');
    let linksCounter = document.querySelector('#ahp-links-counter');

    // Check that root DIV of the editor exists then stop looking for it
    if ( editorRootDiv && editorRootDiv.childNodes.length !== 0 ) {        
        let saveButton = document.querySelector('.editor-post-publish-button__button');

        if (!linksCounter) {
            let editToolbar = document.querySelector('.edit-post-header__toolbar');
            let linksCounter = document.createElement('div');
            linksCounter.setAttribute('id', 'ahp-links-counter');
            editToolbar.append(linksCounter);
        }

        observer.disconnect();

        // Start looking for any changes in the editor's block DIV
        let alreadyWas = [];
        for (const mutation of mutationList) {
            let linksCounter = document.querySelector('#ahp-links-counter');
            if ( mutation.type === 'childList' && !alreadyWas.includes(mutation.target) ) { 
                let postLinks = editorRootDiv.querySelectorAll('a');
                for (let a = 0; a < postLinks.length; a++) {
                    console.log(postLinks[a]);
                };
                alreadyWas.push(mutation.target);
                linksCounter.innerText = postLinks.length + ' link(s) have been discovered so far';
                if (postLinks.length < 5) {
                    saveButton.setAttribute('aria-disabled', 'true');
                    saveButton.disabled = true;
                    linksCounter.innerText += ', 5 required';
                } else {                    
                    saveButton.setAttribute('aria-disabled', 'false');
                    saveButton.disabled = false;
                };
            }
        };
        observer.observe(editorRootDiv, config);
    }
}

const observer = new MutationObserver(callback);
observer.observe(body, config);