<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://github.com/coffee347
 * @since      1.0.0
 *
 * @package    Gb_Link_Counter
 * @subpackage Gb_Link_Counter/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Gb_Link_Counter
 * @subpackage Gb_Link_Counter/includes
 * @author     Alex <aleksander.savenkov@outlook.com>
 */
class Gb_Link_Counter_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
