<?php

/**
 * Fired during plugin activation
 *
 * @link       https://github.com/coffee347
 * @since      1.0.0
 *
 * @package    Gb_Link_Counter
 * @subpackage Gb_Link_Counter/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Gb_Link_Counter
 * @subpackage Gb_Link_Counter/includes
 * @author     Alex <aleksander.savenkov@outlook.com>
 */
class Gb_Link_Counter_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
